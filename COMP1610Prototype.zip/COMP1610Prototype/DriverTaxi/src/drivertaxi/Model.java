/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drivertaxi;

import webservice.Driver;
import webservice.Log;

/**
 *
 * @author ub2232e
 */
/*Please make sure to use the Web Service Methods here. 
Drag the selected method
Change to public
And you can use it Model.selected() in another class
 */
public class Model {

    public static String getCalculation(java.lang.String one, java.lang.String two, java.lang.String textOne, java.lang.String textTwo) {
        webservice.TaxiService_Service service = new webservice.TaxiService_Service();
        webservice.TaxiService port = service.getTaxiServicePort();
        return port.getCalculation(one, two, textOne, textTwo);
    }

    public static java.util.List<java.lang.String> getDriver(java.lang.String name) {
        webservice.TaxiService_Service service = new webservice.TaxiService_Service();
        webservice.TaxiService port = service.getTaxiServicePort();
        return port.getDriver(name);
    }

    public static Driver getDriverInformation(java.lang.String username, java.lang.String password) {
        webservice.TaxiService_Service service = new webservice.TaxiService_Service();
        webservice.TaxiService port = service.getTaxiServicePort();
        return port.getDriverInformation(username, password);
    }

    public static Log getIDName(java.lang.String driverName, int randomNumber) {
        webservice.TaxiService_Service service = new webservice.TaxiService_Service();
        webservice.TaxiService port = service.getTaxiServicePort();
        return port.getIDName(driverName, randomNumber);
    }

    public static void createLog(java.lang.String driverName, java.lang.String logType, java.lang.String logStart, java.lang.String logStartClock, int randomNumber) {
        webservice.TaxiService_Service service = new webservice.TaxiService_Service();
        webservice.TaxiService port = service.getTaxiServicePort();
        port.createLog(driverName, logType, logStart, logStartClock, randomNumber);
    }

    public static void updateLog(java.lang.String logEndTime, java.lang.String logEndTimeClock, java.lang.String calculateTime, int id) {
        webservice.TaxiService_Service service = new webservice.TaxiService_Service();
        webservice.TaxiService port = service.getTaxiServicePort();
        port.updateLog(logEndTime, logEndTimeClock, calculateTime, id);
    }

    public static Log getID(java.lang.String driverName) {
        webservice.TaxiService_Service service = new webservice.TaxiService_Service();
        webservice.TaxiService port = service.getTaxiServicePort();
        return port.getID(driverName);
    }
}
