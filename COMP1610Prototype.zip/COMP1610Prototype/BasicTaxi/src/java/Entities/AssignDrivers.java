/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author ub2232e
 */
@Entity
@Table(name="AssignDrivers")
public class AssignDrivers implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private int driverID;
    private String driverName;
    private String trainingTypes;
    private String ttExpiryDate;
    private String time;
    private String comments;

    public AssignDrivers() {
    }

    public AssignDrivers(int driverID, String driverName, 
            String trainingTypes, 
            String ttExpiryDate, 
            String time, String comments) {
        this.driverID = driverID;
        this.driverName = driverName;
        this.trainingTypes = trainingTypes;
        this.ttExpiryDate = ttExpiryDate;
        this.time = time;
        this.comments = comments;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDriverID() {
        return driverID;
    }

    public void setDriverID(int driverID) {
        this.driverID = driverID;
    }

    public String getTrainingTypes() {
        return trainingTypes;
    }

    public void setTrainingTypes(String trainingTypes) {
        this.trainingTypes = trainingTypes;
    }

    public String getTtExpiryDate() {
        return ttExpiryDate;
    }

    public void setTtExpiryDate(String ttExpiryDate) {
        this.ttExpiryDate = ttExpiryDate;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }
    
    
}
