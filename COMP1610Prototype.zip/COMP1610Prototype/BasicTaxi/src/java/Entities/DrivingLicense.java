/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author ub2232e
 */
@Entity
@Table(name="DrivingLicense")

public class DrivingLicense implements Serializable {
    
        @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private int driverID;
    private String driverName;
    private String drivingLicense;
    private String dlExpiryDate;

    public DrivingLicense() {
    }

    public DrivingLicense(int driverID, String driverName, String drivingLicense, String dlExpiryDate) {
        this.driverID = driverID;
        this.driverName = driverName;
        this.drivingLicense = drivingLicense;
        this.dlExpiryDate = dlExpiryDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDriverID() {
        return driverID;
    }

    public void setDriverID(int driverID) {
        this.driverID = driverID;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getDrivingLicense() {
        return drivingLicense;
    }

    public void setDrivingLicense(String drivingLicense) {
        this.drivingLicense = drivingLicense;
    }

    public String getDlExpiryDate() {
        return dlExpiryDate;
    }

    public void setDlExpiryDate(String dlExpiryDate) {
        this.dlExpiryDate = dlExpiryDate;
    }
    
    
}
