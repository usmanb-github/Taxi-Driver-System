/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author ub2232e
 */
@Entity
@Table(name = "Log")

public class Log implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String driverName;
    private String logType;
    
    private String logStartTimeClock;
    private String logStartTime;

    private String logEndTimeClock;
    private String logEndTime;
    private String calculatedTime;
    private int randomNumber;

    public Log() {
    }

    public Log(String driverName, String logType, String logStartTime, String logEndTime, String calculatedTime) {
        this.driverName = driverName;
        this.logType = logType;
        this.logStartTime = logStartTime;
        this.logEndTime = logEndTime;
        this.calculatedTime = calculatedTime;
    }

    public Log(String driverName, String logType, String logStartTime, String logTimeStartClock, int randomNumber) {
        this.driverName = driverName;
        this.logType = logType;
        this.logStartTime = logStartTime;
        this.logStartTimeClock = logTimeStartClock;
        this.randomNumber = randomNumber;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getLogType() {
        return logType;
    }

    public void setLogType(String logType) {
        this.logType = logType;
    }

    public String getLogStartTime() {
        return logStartTime;
    }

    public void setLogStartTime(String logStartTime) {
        this.logStartTime = logStartTime;
    }

    public String getLogEndTime() {
        return logEndTime;
    }

    public void setLogEndTime(String logEndTime) {
        this.logEndTime = logEndTime;
    }

    public String getCalculatedTime() {
        return calculatedTime;
    }

    public void setCalculatedTime(String calculatedTime) {
        this.calculatedTime = calculatedTime;
    }

    public int getRandomNumber() {
        return randomNumber;
    }

    public void setRandomNumber(int randomNumber) {
        this.randomNumber = randomNumber;
    }

    public String getLogStartTimeClock() {
        return logStartTimeClock;
    }

    public void setLogStartTimeClock(String logStartTimeClock) {
        this.logStartTimeClock = logStartTimeClock;
    }

    public String getLogEndTimeClock() {
        return logEndTimeClock;
    }

    public void setLogEndTimeClock(String logEndTimeClock) {
        this.logEndTimeClock = logEndTimeClock;
    }

}
