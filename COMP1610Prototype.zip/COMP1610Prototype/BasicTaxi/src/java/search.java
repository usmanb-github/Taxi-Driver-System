import Entities.AssignDrivers;
import Entities.DrivingLicense;
import Entities.GeographicalTest;
import Hibernate.HibernateUtil;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author ub2232e
 */
@WebServlet(urlPatterns = {"/search"})
public class search extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Session session = HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();

            String search = request.getParameter("search");
            String s = search.replaceAll("#[^0-9a-z]#i", search);
            Query queryResult = session.createQuery("from DrivingLicense WHERE driverName LIKE '%" + s + "%'");
            List<DrivingLicense> allDrivers;
            allDrivers = queryResult.list();
            session.getTransaction().commit();
            DrivingLicense drivers = null;
            out.write("<table>");
            out.write("<tr>");
            out.write("<td><b>Driver Name</b></td>");
            out.write("<td><b>Driving License</b></td>");
            out.write("<td><b>Expiry Date</b></td>");
            out.write("</tr>");

            for (int i = 0; i < allDrivers.size(); i++) {
                drivers = (DrivingLicense) allDrivers.get(i);
                String driverName = drivers.getDriverName();
                String drivingLicense = drivers.getDrivingLicense();
                String expiryDate = drivers.getDlExpiryDate();

                out.write("</tr>");
                out.write("<tr>");
                out.write("<td>" + driverName + "</td>");
                out.write("<td>" + drivingLicense + "</td>");
                out.write("<td>" + expiryDate + "</td>");
                out.write("</tr>");
            }
            out.write("</table>");

            Session session2 = HibernateUtil.getSessionFactory().openSession();
            session2.beginTransaction();
            Query queryGeo = session2.createQuery("from GeographicalTest WHERE driverName LIKE '%" + s + "%'");
            List<GeographicalTest> allDriversGeo;
            allDriversGeo = queryGeo.list();
            session2.getTransaction().commit();
            GeographicalTest driversGeo = null;
            out.write("<table>");
            out.write("<tr>");
            out.write("<td><b>Driver Name</b></td>");
            out.write("<td><b>Geographical Test</b></td>");
            out.write("<td><b>Expiry Date</b></td>");
            out.write("</tr>");

            for (int i = 0; i < allDriversGeo.size(); i++) {
                driversGeo = (GeographicalTest) allDriversGeo.get(i);
                String driverName = driversGeo.getDriverName();
                String drivingLicense = driversGeo.getGeographicalTest();
                String expiryDate = driversGeo.getGtExpiryDate();

                out.write("</tr>");
                out.write("<tr>");
                out.write("<td>" + driverName + "</td>");
                out.write("<td>" + drivingLicense + "</td>");
                out.write("<td>" + expiryDate + "</td>");
                out.write("</tr>");
            }
            out.write("</table>");

            Session session3 = HibernateUtil.getSessionFactory().openSession();
            session3.beginTransaction();
            Query queryAssign = session3.createQuery("from AssignDrivers WHERE driverName LIKE '%" + s + "%'");
            List<AssignDrivers> allDriversAssign;
            allDriversAssign = queryAssign.list();
            session3.getTransaction().commit();
            AssignDrivers driversAssign = null;
            out.write("<table>");
            out.write("<tr>");
            out.write("<td><b>Driver Name</b></td>");
            out.write("<td><b>Training Types</b></td>");
            out.write("<td><b>Expiry Date</b></td>");
            out.write("</tr>");

            for (int i = 0; i < allDriversAssign.size(); i++) {
                driversAssign = (AssignDrivers) allDriversAssign.get(i);
                String driverName = driversAssign.getDriverName();
                String drivingLicense = driversAssign.getTrainingTypes();
                String expiryDate = driversAssign.getTtExpiryDate();

                out.write("</tr>");
                out.write("<tr>");
                out.write("<td>" + driverName + "</td>");
                out.write("<td>" + drivingLicense + "</td>");
                out.write("<td>" + expiryDate + "</td>");
                out.write("</tr>");
            }
            out.write("</table>");
        }
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
