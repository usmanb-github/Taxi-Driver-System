
import Entities.Driver;
import Hibernate.HibernateInterface;
import Hibernate.HibernateSingleton;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ub2232e
 */
@WebServlet(urlPatterns = {"/addDriver"})
public class addDriver extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            HibernateInterface db = HibernateSingleton.getInstance();
            int driverID = Integer.parseInt(request.getParameter("driverID"));
            String driverName = request.getParameter("driverName");
            String username = request.getParameter("username");
            String password = request.getParameter("password");

            if (db.retrieveAllDriverInfo(driverID) == null) {
                Driver c = new Driver(driverID, driverName, username, password);
                db.createDriver(c);
                response.sendRedirect("addDriver.jsp");
            } else if (db.retrieveAllDriverInfo(driverID).getDriverID() == driverID) {
                out.write("Try again");
                response.sendRedirect("addDriver.jsp");
            }
        }
    }
//TO DO:-
//VIEW TABLE AND EDIT, DELETE ON TABLE
//ADD TRAINING SCHEDULE

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        /* String action = request.getParameter("drivers");
        if (action == null) {
            HibernateInterface db = HibernateSingleton.getInstance();
            request.setAttribute("list", db.getAllDriver());
            request.getRequestDispatcher("addDriver.jsp").forward(request, response);
        }*/
        processRequest(request, response);

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
