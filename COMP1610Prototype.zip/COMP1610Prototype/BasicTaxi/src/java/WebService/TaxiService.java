/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebService;

import Entities.AssignDrivers;
import Entities.Disciplinary;
import Entities.Driver;
import Entities.DrivingLicense;
import Entities.GeographicalTest;
import Entities.Log;
import Entities.Login;
import Entities.ScheduleSession;
import Entities.TrainingTypes;
import Hibernate.HibernateInterface;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebService;
import javax.ejb.Stateless;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author ub2232e
 */
@WebService(serviceName = "TaxiService")
@Stateless()
public class TaxiService {

    @EJB
    private HibernateInterface ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "getID")
    public Log getID(@WebParam(name = "driverName") String driverName) {
        return ejbRef.getID(driverName);
    }

    @WebMethod(operationName = "getIDName")
    public Log getIDName(@WebParam(name = "driverName") String driverName, @WebParam(name = "randomNumber") int randomNumber) {
        return ejbRef.getIDName(driverName, randomNumber);
    }

    @WebMethod(operationName = "updateLog")
    @Oneway
    public void updateLog(@WebParam(name = "logEndTime") String logEndTime, @WebParam(name = "logEndTimeClock") String logEndTimeClock, @WebParam(name = "calculateTime") String calculateTime, @WebParam(name = "ID") int ID) {
        ejbRef.updateLog(logEndTime, logEndTimeClock, calculateTime, ID);
    }

    @WebMethod(operationName = "retrieveAllLicenseInfo")
    public DrivingLicense retrieveAllLicenseInfo(@WebParam(name = "drivingLicense") String drivingLicense, @WebParam(name = "driverID") int driverID) {
        return ejbRef.retrieveAllLicenseInfo(drivingLicense, driverID);
    }

    @WebMethod(operationName = "retrieveAllDriverInfo")
    public Driver retrieveAllDriverInfo(@WebParam(name = "driverID") int driverID) {
        return ejbRef.retrieveAllDriverInfo(driverID);
    }

    @WebMethod(operationName = "createAssignDrivers")
    @Oneway
    public void createAssignDrivers(@WebParam(name = "c") AssignDrivers c) {
        ejbRef.createAssignDrivers(c);
    }

    @WebMethod(operationName = "retrieveAssignDrivers")
    public List<AssignDrivers> retrieveAssignDrivers() {
        return ejbRef.retrieveAssignDrivers();
    }

    @WebMethod(operationName = "createLog")
    @Oneway
    public void createLog(@WebParam(name = "driverName") String driverName, @WebParam(name = "logType") String logType, @WebParam(name = "logStart") String logStart, @WebParam(name = "logStartClock") String logStartClock, @WebParam(name = "randomNumber") int randomNumber) {
        ejbRef.createLog(driverName, logType, logStart, logStartClock, randomNumber);
    }

    @WebMethod(operationName = "retrieveScheduleSession")
    public List<ScheduleSession> retrieveScheduleSession() {
        return ejbRef.retrieveScheduleSession();
    }

    @WebMethod(operationName = "createScheduleSession")
    @Oneway
    public void createScheduleSession(@WebParam(name = "c") ScheduleSession c) {
        ejbRef.createScheduleSession(c);
    }

    @WebMethod(operationName = "getDriver")
    public List<String> getDriver(@WebParam(name = "name") String name) {
        return ejbRef.getDriver(name);
    }

    @WebMethod(operationName = "getCalculation")
    public String getCalculation(@WebParam(name = "one") String one, @WebParam(name = "two") String two, @WebParam(name = "textOne") String textOne, @WebParam(name = "textTwo") String textTwo) {
        return ejbRef.getCalculation(one, two, textOne, textTwo);
    }

    @WebMethod(operationName = "retrieveDisciplinary")
    public List<Disciplinary> retrieveDisciplinary() {
        return ejbRef.retrieveDisciplinary();
    }

    @WebMethod(operationName = "createDisciplinary")
    @Oneway
    public void createDisciplinary(@WebParam(name = "c") Disciplinary c) {
        ejbRef.createDisciplinary(c);
    }

    @WebMethod(operationName = "retrieveDrivingLicense")
    public List<DrivingLicense> retrieveDrivingLicense() {
        return ejbRef.retrieveDrivingLicense();
    }

    @WebMethod(operationName = "updateDrivingLicense")
    @Oneway
    public void updateDrivingLicense(@WebParam(name = "drivingLicence") String drivingLicence, @WebParam(name = "dlExpiryDate") String dlExpiryDate, @WebParam(name = "ID") int ID) {
        ejbRef.updateDrivingLicense(drivingLicence, dlExpiryDate, ID);
    }

    @WebMethod(operationName = "deleteDrivingLicense")
    @Oneway
    public void deleteDrivingLicense(@WebParam(name = "ID") int ID) {
        ejbRef.deleteDrivingLicense(ID);
    }

    @WebMethod(operationName = "deleteTrainingTypes")
    @Oneway
    public void deleteTrainingTypes(@WebParam(name = "ID") int ID) {
        ejbRef.deleteTrainingTypes(ID);
    }

    @WebMethod(operationName = "createDrivingLicense")
    @Oneway
    public void createDrivingLicense(@WebParam(name = "c") DrivingLicense c) {
        ejbRef.createDrivingLicense(c);
    }

    @WebMethod(operationName = "updateTrainingTypes")
    @Oneway
    public void updateTrainingTypes(@WebParam(name = "trainingTypes") String trainingTypes, @WebParam(name = "ID") int ID) {
        ejbRef.updateTrainingTypes(trainingTypes, ID);
    }

    @WebMethod(operationName = "retrieveTrainingTypes")
    public List<TrainingTypes> retrieveTrainingTypes() {
        return ejbRef.retrieveTrainingTypes();
    }

    @WebMethod(operationName = "createTrainingTypes")
    @Oneway
    public void createTrainingTypes(@WebParam(name = "c") TrainingTypes c) {
        ejbRef.createTrainingTypes(c);
    }

    @WebMethod(operationName = "retrieveDriver")
    public List<Driver> retrieveDriver() {
        return ejbRef.retrieveDriver();
    }

    @WebMethod(operationName = "getDriverInformation")
    public Driver getDriverInformation(@WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        return ejbRef.getDriverInformation(username, password);
    }

    @WebMethod(operationName = "deleteQualification")
    @Oneway
    public void deleteQualification(@WebParam(name = "ID") int ID) {
        ejbRef.deleteQualification(ID);
    }

    @WebMethod(operationName = "updateQualification")
    @Oneway
    public void updateQualification(@WebParam(name = "driverID") int driverID, @WebParam(name = "driverName") String driverName, @WebParam(name = "geographicalTest") String geographicalTest, @WebParam(name = "gtExpiryDate") String gtExpiryDate, @WebParam(name = "ID") int ID) {
        ejbRef.updateQualification(driverID, driverName, geographicalTest, gtExpiryDate, ID);
    }

    @WebMethod(operationName = "retrieveQualification")
    public List<GeographicalTest> retrieveQualification() {
        return ejbRef.retrieveQualification();
    }

    @WebMethod(operationName = "retrieveLogin")
    public Login retrieveLogin(@WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        return ejbRef.retrieveLogin(username, password);
    }

    @WebMethod(operationName = "createDriver")
    @Oneway
    public void createDriver(@WebParam(name = "c") Driver c) {
        ejbRef.createDriver(c);
    }

    @WebMethod(operationName = "createQualification")
    @Oneway
    public void createQualification(@WebParam(name = "c") GeographicalTest c) {
        ejbRef.createQualification(c);
    }

    @WebMethod(operationName = "updateDriver")
    @Oneway
    public void updateDriver(@WebParam(name = "driverID") int driverID, @WebParam(name = "driverName") String driverName, @WebParam(name = "username") String username, @WebParam(name = "password") String password, @WebParam(name = "ID") int ID) {
        ejbRef.updateDriver(driverID, driverName, username, password, ID);
    }

    @WebMethod(operationName = "deleteDriver")
    @Oneway
    public void deleteDriver(@WebParam(name = "ID") int ID) {
        ejbRef.deleteDriver(ID);
    }
    
}
