package Hibernate;

import Entities.AssignDrivers;
import Entities.Disciplinary;
import Entities.Driver;
import Entities.DrivingLicense;
import Entities.Login;
import Entities.GeographicalTest;
import Entities.Log;
import Entities.ScheduleSession;
import Entities.TrainingTypes;
import java.util.List;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author ub2232e
 */
//try change 
public interface HibernateInterface {

    Log getID(String driverName);

    Log getIDName(String driverName, int randomNumber);

    void updateLog(String logEndTime, String logEndTimeClock, String calculateTime, int ID);

    DrivingLicense retrieveAllLicenseInfo(String drivingLicense, int driverID);

    Driver retrieveAllDriverInfo(int driverID);

    void createAssignDrivers(AssignDrivers c);

    List<AssignDrivers> retrieveAssignDrivers();

    void createLog(String driverName, String logType, String logStart, String logStartClock, int randomNumber);

    List<ScheduleSession> retrieveScheduleSession();

    void createScheduleSession(ScheduleSession c);

    abstract List<String> getDriver(String name);

    abstract String getCalculation(String one, String two, String textOne, String textTwo);

    List<Disciplinary> retrieveDisciplinary();

    void createDisciplinary(Disciplinary c);

    abstract List<DrivingLicense> retrieveDrivingLicense();

    abstract void updateDrivingLicense(String drivingLicence,
            String dlExpiryDate, int ID);

    abstract void deleteDrivingLicense(int ID);

    abstract void deleteTrainingTypes(int ID);

    abstract void createDrivingLicense(DrivingLicense c);

    abstract void updateTrainingTypes(String trainingTypes, int ID);

    abstract List<TrainingTypes> retrieveTrainingTypes();

    abstract void createTrainingTypes(TrainingTypes c);

    abstract List<Driver> retrieveDriver();

    abstract Driver getDriverInformation(String username, String password);

    abstract void deleteQualification(int ID);

    abstract void updateQualification(int driverID, String driverName, String geographicalTest,
            String gtExpiryDate, int ID);

    abstract List<GeographicalTest> retrieveQualification();

    abstract Login retrieveLogin(String username, String password);

    abstract void createDriver(Driver c);

    abstract void createQualification(GeographicalTest c);

    abstract void updateDriver(int driverID, String driverName, String username, String password, int ID);

    void deleteDriver(int ID);
}
