package Hibernate;

import Entities.AssignDrivers;
import Entities.Disciplinary;
import Entities.Driver;
import Entities.DrivingLicense;
import Entities.Login;
import Entities.GeographicalTest;
import Entities.Log;
import Entities.ScheduleSession;
import Entities.TrainingTypes;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author ub2232e
 */
@Stateless
public class HibernateSingleton implements HibernateInterface {

    private static HibernateSingleton firstInstance = null; // Singleton instance declared

    protected HibernateSingleton() {

    }

    public static HibernateSingleton getInstance() {
        if (firstInstance == null) {
            firstInstance = new HibernateSingleton();
        }
        return firstInstance;
    }

    @Override
    public void createDriver(Driver c) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.save(c);
        session.getTransaction().commit();
    }

    @Override
    public void createScheduleSession(ScheduleSession c) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.save(c);
        session.getTransaction().commit();
    }

    @Override
    public void createDrivingLicense(DrivingLicense c) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.save(c);
        session.getTransaction().commit();
    }

    @Override
    public void createLog(String driverName, String logType, String logStart, String logStartClock, int randomNumber) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Log c = new Log(driverName, logType, logStart, logStartClock, randomNumber);
        session.save(c);
        session.getTransaction().commit();
    }

    @Override
    public void updateLog(String logEndTime, String logEndTimeClock, String calculateTime, int ID) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        String queryString = "UPDATE from Log SET logEndTime=:logEndTime, logEndTimeClock=:logEndTimeClock, "
                + "calculatedTime=:calculatedTime "
                + "WHERE ID=:ID";
        Query query = session.createQuery(queryString);
        query.setString("logEndTimeClock", logEndTimeClock);
        query.setString("logEndTime", logEndTime);
        query.setString("calculatedTime", calculateTime);
        query.setInteger("ID", ID);
        query.executeUpdate();
        session.getTransaction().commit();
    }

    @Override
    public void createAssignDrivers(AssignDrivers c) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.save(c);
        session.getTransaction().commit();
    }

    @Override
    public void createDisciplinary(Disciplinary c) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.save(c);
        session.getTransaction().commit();
    }

    @Override
    public void createTrainingTypes(TrainingTypes c) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.save(c);
        session.getTransaction().commit();
    }

    @Override
    public void createQualification(GeographicalTest c) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.save(c);
        session.getTransaction().commit();
    }

    @Override
    public Log getIDName(String driverName, int randomNumber) {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            Query queryResult = session.createQuery("from Log WHERE driverName=:driverName AND randomNumber=:randomNumber");
            queryResult.setString("driverName", driverName);
            queryResult.setInteger("randomNumber", randomNumber);

            List<Log> allLog;
            allLog = queryResult.list();
            session.getTransaction().commit();

            Log log = null;
            for (int i = 0; i < allLog.size(); i++) {
                log = (Log) allLog.get(i);
            }
            return log;
        } catch (HibernateException e) {
            return null;
        }
    }
    
    @Override
    public Log getID(String driverName) {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            Query queryResult = session.createQuery("from Log WHERE driverName=:driverName");
            queryResult.setString("driverName", driverName);

            List<Log> allLog;
            allLog = queryResult.list();
            session.getTransaction().commit();

            Log log = null;
            for (int i = 0; i < allLog.size(); i++) {
                log = (Log) allLog.get(i);
            }
            return log;
        } catch (HibernateException e) {
            return null;
        }
    }

    @Override
    public Login retrieveLogin(String username, String password) {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            Query queryResult = session.createQuery("from Login WHERE username =:username and password=:password");
            queryResult.setString("username", username);
            queryResult.setString("password", password);
            List<Login> allLogin;
            allLogin = queryResult.list();
            session.getTransaction().commit();

            Login login = null;
            for (int i = 0; i < allLogin.size(); i++) {
                login = (Login) allLogin.get(i);
            }
            return login;
        } catch (HibernateException e) {
            return null;
        }
    }

    @Override
    public List<Driver> retrieveDriver() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        List<Driver> driverList = session.createQuery("from Driver").list();
        return driverList;
    }

    @Override
    public List<GeographicalTest> retrieveQualification() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        List<GeographicalTest> qualificationList = session.createQuery("from GeographicalTest").list();
        return qualificationList;
    }

    @Override
    public List<AssignDrivers> retrieveAssignDrivers() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        List<AssignDrivers> qualificationList = session.createQuery("from AssignDrivers").list();
        return qualificationList;
    }

    @Override
    public List<ScheduleSession> retrieveScheduleSession() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        List<ScheduleSession> qualificationList = session.createQuery("from ScheduleSession").list();
        return qualificationList;
    }

    @Override
    public List<DrivingLicense> retrieveDrivingLicense() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        List<DrivingLicense> licenseList = session.createQuery("from DrivingLicense").list();
        return licenseList;
    }

    @Override
    public List<Disciplinary> retrieveDisciplinary() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        List<Disciplinary> licenseList = session.createQuery("from Disciplinary").list();
        return licenseList;
    }

    @Override
    public List<TrainingTypes> retrieveTrainingTypes() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        List<TrainingTypes> qualificationList = session.createQuery("from TrainingTypes").list();
        return qualificationList;
    }

    @Override
    public DrivingLicense retrieveAllLicenseInfo(String drivingLicense, int driverID) {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            Query queryResult = session.createQuery("from DrivingLicense Where drivingLicense=:drivingLicense AND driverID=:driverID");
            queryResult.setString("drivingLicense", drivingLicense);
            queryResult.setInteger("driverID", driverID);

            List<DrivingLicense> allLicense;
            allLicense = queryResult.list();
            session.getTransaction().commit();

            DrivingLicense license = null;
            for (int i = 0; i < allLicense.size(); i++) {
                license = (DrivingLicense) allLicense.get(i);
            }
            return license;
        } catch (HibernateException e) {
            return null;
        }
    }

    @Override
    public Driver retrieveAllDriverInfo(int driverID) {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            Query queryResult = session.createQuery("from Driver Where driverID =:driverID");
            queryResult.setInteger("driverID", driverID);
            List<Driver> allDrivers;
            allDrivers = queryResult.list();
            session.getTransaction().commit();

            Driver drivers = null;
            for (int i = 0; i < allDrivers.size(); i++) {
                drivers = (Driver) allDrivers.get(i);
            }
            return drivers;
        } catch (HibernateException e) {
            return null;
        }
    }

    @Override
    public Driver getDriverInformation(String username, String password) {
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            Query queryResult = session.createQuery("from Driver WHERE username =:username and password=:password");
            queryResult.setString("username", username);
            queryResult.setString("password", password);
            List<Driver> allDrivers;
            allDrivers = queryResult.list();
            session.getTransaction().commit();

            Driver drivers = null;
            for (int i = 0; i < allDrivers.size(); i++) {
                drivers = (Driver) allDrivers.get(i);
            }
            return drivers;
        } catch (HibernateException e) {
            return null;
        }
    }

    @Override
    public void updateQualification(int driverID, String driverName,
            String geographicalTest, String gtExpiryDate, int ID) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        String queryString = "UPDATE from GeographicalTest SET driverID = :driverID, "
                + " driverName = :driverName, "
                + "geographicalTest = :geographicalTest,"
                + "gtExpiryDate =:gtExpiryDate where ID = :ID";
        Query query = session.createQuery(queryString);
        query.setInteger("driverID", driverID);
        query.setString("driverName", driverName);
        query.setString("geographicalTest", geographicalTest);
        query.setString("gtExpiryDate", gtExpiryDate);
        query.setInteger("ID", ID);
        query.executeUpdate();
        session.getTransaction().commit();
    }

    @Override
    public void deleteQualification(int ID) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        String queryString = "DELETE from GeographicalTest where ID = :ID";
        Query query = session.createQuery(queryString);
        query.setInteger("ID", ID);
        query.executeUpdate();
        session.getTransaction().commit();
    }

    @Override
    public void updateDriver(int driverID, String driverName,
            String username, String password,
            int ID) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        String queryString = "UPDATE from Driver SET driverID = :driverID, driverName = :driverName, username=:username, password=:password where ID = :ID";
        Query query = session.createQuery(queryString);
        query.setInteger("driverID", driverID);
        query.setString("driverName", driverName);
        query.setString("username", username);
        query.setString("password", password);

        query.setInteger("ID", ID);
        query.executeUpdate();
        session.getTransaction().commit();
    }

    @Override
    public void deleteDriver(int ID) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        String queryString = "DELETE from Driver where ID = :ID";
        Query query = session.createQuery(queryString);
        query.setInteger("ID", ID);
        query.executeUpdate();
        session.getTransaction().commit();
    }

    @Override
    public void updateTrainingTypes(String trainingTypes, int ID) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        String queryString = "UPDATE from TrainingTypes SET trainingTypes = :trainingTypes where ID = :ID";
        Query query = session.createQuery(queryString);
        query.setString("trainingTypes", trainingTypes);
        query.setInteger("ID", ID);
        query.executeUpdate();
        session.getTransaction().commit();
    }

    @Override
    public void deleteTrainingTypes(int ID) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        String queryString = "DELETE from TrainingTypes where ID = :ID";
        Query query = session.createQuery(queryString);
        query.setInteger("ID", ID);
        query.executeUpdate();
        session.getTransaction().commit();
    }

    @Override
    public void updateDrivingLicense(String drivingLicence, String dlExpiryDate, int ID) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        String queryString = "UPDATE from DrivingLicense SET drivingLicense = :drivingLicense,  dlExpiryDate = :dlExpiryDate WHERE ID=:ID ";
        Query query = session.createQuery(queryString);
        query.setString("drivingLicense", drivingLicence);
        query.setString("dlExpiryDate", dlExpiryDate);
        query.setInteger("ID", ID);
        query.executeUpdate();
        session.getTransaction().commit();
    }

    @Override
    public void deleteDrivingLicense(int ID) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        String queryString = "DELETE from DrivingLicense where ID = :ID";
        Query query = session.createQuery(queryString);
        query.setInteger("ID", ID);
        query.executeUpdate();
        session.getTransaction().commit();
    }

    @Override
    public String getCalculation(String startAMLog, String endPMLog,
            String startTimeLog, String endTimeLog) {
        try {
            DateTimeFormatter formatLog1 = new DateTimeFormatterBuilder().appendPattern("h:mm").parseDefaulting(ChronoField.AMPM_OF_DAY, 0).toFormatter();
            DateTimeFormatter formatLog2 = new DateTimeFormatterBuilder().appendPattern("h:mm").parseDefaulting(ChronoField.AMPM_OF_DAY, 1).toFormatter();

            if ("AM".equals(startAMLog) && "AM".equals(endPMLog)) {
                LocalTime localTimeLog1 = LocalTime.parse(startTimeLog, formatLog1);
                LocalTime localTimeLog2 = LocalTime.parse(endTimeLog, formatLog1);
                Duration durationLogCalculation = Duration.between(localTimeLog1, localTimeLog2);
                long minutesLog = durationLogCalculation.toMinutes();
                long result = minutesLog - (durationLogCalculation.toHours() * 60);
                return "Time in hours: " + durationLogCalculation.toHours() + " hours" + " and " + result + " minutes ";
            } else if ("PM".equals(startAMLog) && "PM".equals(endPMLog)) {
                LocalTime logcalTimeLog1 = LocalTime.parse(startTimeLog, formatLog2);
                LocalTime localTimeLog2 = LocalTime.parse(endTimeLog, formatLog2);
                Duration durationLogCalculation = Duration.between(logcalTimeLog1, localTimeLog2);
                long minutesLog = durationLogCalculation.toMinutes();
                long result = minutesLog - (durationLogCalculation.toHours() * 60);
                return "Time in hours: " + durationLogCalculation.toHours() + " hours" + " and " + result + " minutes ";
            } else if ("AM".equals(startAMLog) && "PM".equals(endPMLog)) {
                LocalTime localTimeLog1 = LocalTime.parse(startTimeLog, formatLog1);
                LocalTime localTimeLog2 = LocalTime.parse(endTimeLog, formatLog2);
                Duration durationLogCalculation = Duration.between(localTimeLog1, localTimeLog2);
                long minutesLog = durationLogCalculation.toMinutes();
                long result = minutesLog - (durationLogCalculation.toHours() * 60);
                return "Time in hours: " + durationLogCalculation.toHours() + " hours" + " and " + result + " minutes ";
            } else if ("PM".equals(startAMLog) && "AM".equals(endPMLog)) {
                LocalTime timeLocalLog1 = LocalTime.parse(startTimeLog, formatLog2);
                LocalTime timeLocalLog2 = LocalTime.parse(endTimeLog, formatLog1);
                Duration durationLogCalculation = Duration.between(timeLocalLog1, timeLocalLog2);
                long minutesLog = durationLogCalculation.toMinutes();

                long result = minutesLog - (durationLogCalculation.toHours() * 60);
                return "Time in hours: " + durationLogCalculation.toHours() + " hours" + " and " + result + " minutes ";
            }
        } catch (Exception e) {
            return "Please enter the correct format." + startAMLog + endPMLog + startTimeLog + endTimeLog;
        }
        return null;
    }

    @Override
    public List<String> getDriver(String name) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query queryResult = session.createQuery("from Driver Where username =:name");
        queryResult.setString("name", name);

        List<Driver> alLDrivers;
        alLDrivers = queryResult.list();
        List<String> a = new ArrayList<>();
        session.getTransaction().commit();
        Driver q = null;
        for (int i = 0; i < alLDrivers.size(); i++) {
            q = (Driver) alLDrivers.get(i);
            a.add(q.getDriverName());
        }
        return a;
    }
}
